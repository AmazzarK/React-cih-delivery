import React from 'react'

const Footer = () => {
  return (
    <>
        <div className="text-center"> Copyright Cih Bank &copy; 2024 </div>
    </>
  )
}

export default Footer